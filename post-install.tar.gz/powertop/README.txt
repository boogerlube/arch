copy powertop.service to /etc/systemd/system

sudo systemctl enable --now powertop.service