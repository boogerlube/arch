sudo cp powertop.service /etc/systemd/system
sudo systemctl enable --now powertop.service