Wall Clock Theme for CobiAnalogClock Desklet
============================================

License: CC-BY http://creativecommons.org/licenses/by/3.0/
by jorgenqv, February 2016

Based on
3Quarks - SVG Railway Station Clock
http://www.3quarks.com/en/SVGClock/
Siemens Wall Clock (made from a photo by Gerhard Joch)
by Rüdiger Appel, December 2012
Creative Commons 3.0 License
http://creativecommons.org/licenses/by/3.0/
