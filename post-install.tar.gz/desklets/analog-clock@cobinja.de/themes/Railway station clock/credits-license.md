Railway Station Clock Theme for CobiAnalogClock Desklet
=======================================================

License: CC-BY-SA http://creativecommons.org/licenses/by-sa/2.5/
by jorgenqv, February 2016

Based on
https://commons.wikimedia.org/wiki/File:Animierte_DB_Uhr.svg
by Hk kng 
and
http://commons.wikimedia.org/wiki/File:Station_Clock.svg
Retouched version of Image:LindauBahnhof3.jpg, Station_Clock.jpg, image of an german railway station clock
https://commons.wikimedia.org/wiki/File:LindauBahnhof4.jpg
by FischX (derivative work), Station_Clock.jpg: User:JuergenG, User:AlMare
