The `iconmeta.json` file in this directory is suitable for use with the 
the icon set by d3stroy which is available from 

http://d3stroy.deviantart.com/art/Weather-Icons-I-32934189