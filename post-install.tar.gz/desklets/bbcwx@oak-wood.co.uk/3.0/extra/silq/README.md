The `iconmeta.json` file in this directory is suitable for use with the 
"SILq" icon set which is available from 

http://d3stroy.deviantart.com/art/SILq-Weather-Icons-356609017