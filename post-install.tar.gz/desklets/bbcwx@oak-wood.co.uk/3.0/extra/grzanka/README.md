The `iconmeta.json` file in this directory is suitable for use with the 
"Grzanka's Icons nr 2" icon set which is available from 

http://voogee.deviantart.com/art/Grzanka-s-Icons-nr-2-44204272

This file is also suitable for many icon sets designed for use with
Yahoo! and The Weather Channel (weather.com) and the Weather Docklet. 
See also sticker