The `iconmeta.json` file in this directory is suitable for use with the 
"Sketcy Weather Icons Glow ed" icon set which is available from 

http://azuresol.deviantart.com/art/Sketcy-Weather-Icons-Glow-ed-135079488