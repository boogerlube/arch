The `iconmeta.json` file in this directory is suitable for use with the 
"Unity 1.0" icon set which is available from 

http://rago.deviantart.com/art/Weather-Icon-Set-Unity-1-0-44443295