The `iconmeta.json` file in this directory is suitable for use with the
icon set by Umutavci which is available from

<http://umutavci.deviantart.com/art/weather-icon-set-165476034>
