The `iconmeta.json` file in this directory is suitable for use with the
icon set by Mohitg which is available from

<http://mohitg.deviantart.com/art/Weather-Touch-Icons-Weather7-150190245>
