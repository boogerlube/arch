The `iconmeta.json` file in this directory is suitable for use with the
"Sticker Weather Icons" icon set which is available from

<http://kortoik.deviantart.com/art/Sticker-Weather-Icons-78827487>

Note that because of the thin white border around these icons they
do not scale well. They come in three sizes and you should experiment
to see which size works best for you. If you have the large current
conditions icon turned off the 64px will likely be best. Otherwise
128px may be preferable.

This file is also suitable for many icon sets designed for use with
Yahoo! and The Weather Channel (weather.com)
