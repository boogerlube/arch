The `iconmeta.json` file in this directory is suitable for use with the
"tick weather icons" icon set which is available from

<http://xiao4.deviantart.com/art/tick-weather-icons-96294478>
