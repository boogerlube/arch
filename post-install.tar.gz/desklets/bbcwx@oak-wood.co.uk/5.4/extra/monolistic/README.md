The `iconmeta.json` file in this directory is suitable for use with the
monolistic's icon set which is available from

<http://monolistic.deviantart.com/art/The-Weather-31004443>
