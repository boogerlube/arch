#!/bin/bash

hyprctl --batch "keyword decoration:rounding 14 ; keyword general:gaps_out 20 ; keyword general:gaps_in 10 ; keyword general:border_size 2"
