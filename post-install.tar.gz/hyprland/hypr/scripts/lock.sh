#!/bin/bash
hyprlock
