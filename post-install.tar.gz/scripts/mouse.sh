#sudo echo 'disabled' > '/sys/bus/usb/devices/1-2.2/power/wakeup'
#sudo echo 'disabled' > '/sys/bus/usb/devices/3-3/power/wakeup'
echo 'disabled' | sudo tee -a "/sys/bus/usb/devices/3-3/power/wakeup"
