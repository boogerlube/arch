MEDIA="Music"

# Make sure disk device exists before beginning
if ! [ -e /run/media/bob/$MEDIA ] ; then
   echo "\nBackup device ("$MEDIA") does not exist!"
   exit 1
fi

rsync -av --progress --delete  root@pinky:/mnt/user/media/Mvid/ /run/media/bob/$MEDIA/Mvid/

rsync -av --progress --delete  root@pinky:/mnt/user/media/Music/ /run/media/bob/$MEDIA/Music/

rsync -av --progress --delete ~/Books/ /run/media/bob/$MEDIA/Books/