sudo echo XHC0 > /proc/acpi/wakeup
sudo systemctl suspend
