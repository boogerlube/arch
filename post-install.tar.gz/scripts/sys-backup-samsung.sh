sudo rsync -aAXv --delete --exclude=/dev/* --exclude=/proc/* --exclude /home/bob/.cache --exclude=/sys/* --exclude=/tmp/* --exclude=/run/* --exclude=/mnt/* --exclude=/media/* --exclude="swapfile" --exclude="lost+found" --exclude=".VirtualBoxVMs" --exclude=".ecryptfs" / /run/media/bob/Sam2TB/chickenhawk
sudo rsync -aAXv --delete /home/bob/.cache/evolution /run/media/bob/Sam2TB/chickenhawk/home/bob/.cache/
#
#Restore with:
#
#sudo rsync -aAXv --delete --exclude="lost+found" /run/media/bob/Sam2TB/chickenhawk /
