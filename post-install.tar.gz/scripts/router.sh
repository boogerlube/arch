#################################################################################
####                                                                         ####
####                   Use this script to copy music and books               ####
####                        to SD card for GL-inet router                    ####
####                                                                         ####
#################################################################################

#Check to see if SD card is ready.
if ! [ -e /run/media/bob/4EF3-FFA6/ ] ; then
  echo "SD card NOT mounted!"
  exit 1
fi

rsync -av --progress --delete /media/brain/Music/ /run/media/bob/4EF3-FFA6/Music/
rsync -av --progress --delete ~/Books/ /run/media/bob/4EF3-FFA6/Books/
