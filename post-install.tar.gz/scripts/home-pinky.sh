rsync -av --progress --delete --exclude '.local/share/Trash/' --exclude '.var' --exclude '.cache' --exclude '.steam' ~/ root@pinky:/mnt/disks/remote01/porky/
