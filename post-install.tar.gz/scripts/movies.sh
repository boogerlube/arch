device="/run/media/bob/Movies"

if ! [ -e $device ] ; then
  echo -e "\nBackup device not mounted.\n\n"
  exit
fi

rsync -av --progress --delete  root@pinky:/mnt/user/media/Movies/ $device/
