# must run as root
if [ "$(id -u)" != "0" ]; then
   echo "This script must be run as root" 1>&2
   exit 1
fi

pacman-key --recv-key FBA220DFC880C036 --keyserver keyserver.ubuntu.com

pacman-key --lsign-key FBA220DFC880C036

pacman -U 'https://cdn-mirror.chaotic.cx/chaotic-aur/chaotic-keyring.pkg.tar.zst' 'https://cdn-mirror.chaotic.cx/chaotic-aur/chaotic-mirrorlist.pkg.tar.zst'

# Then Append (adding to the end of the file) to /etc/pacman.conf:

#[chaotic-aur]
#Include = /etc/pacman.d/chaotic-mirrorlist

echo '[chaotic-aur]' | tee -a /etc/pacman.conf
echo 'Include = /etc/pacman.d/chaotic-mirrorlist' | tee -a /etc/pacman.conf