#rsync -av --dry-run --progress --delete --exclude '.var' --exclude '.cache' --exclude '.steam' ~/ /media/bob/USB-Red/bob/

rsync -av --progress --delete --exclude-from=<(cd /media/pinky/TV; find . -type d -regex './[A-Sa-s0-9].+*' | sed -e 's|./||')  /media/pinky/TV/ /media/bob/TV2/
