sudo ~/.local/bin/dotnet-install.sh -c 7.0 --install-dir /usr/share/dotnet
