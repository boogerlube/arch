rsync -av --progress --delete --exclude '.stfolder' root@brain:/mnt/user/media/Music/ /home/bob/Music/
