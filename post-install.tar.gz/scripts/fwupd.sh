sudo fwupdmgr refresh --force
#sudo fwupdmgr enable-remote lvfs-testing --assume-yes
sudo fwupdmgr get-updates
sudo fwupdmgr update
