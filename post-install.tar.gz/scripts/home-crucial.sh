HOST=$(hostname)
MEDIA="Crucial2TB"

# Make sure disk device exists before beginning
if ! [ -e /run/media/bob/$MEDIA ] ; then
   echo -e "\nBackup device ("$MEDIA") is not mounted!"
   exit 1
fi

# Create directory if it doesn't exit
if ! [ -e /run/media/bob/$MEDIA/$HOST ] ; then
   mkdir /run/media/bob/$MEDIA/$HOST
fi

rsync -aAXv --progress --delete \
  --exclude 'yay' \
  --exclude 'Music' \
  --exclude 'Books' \
  --exclude '.local/share/Trash/' \
  --exclude '.var' \
  --exclude '.cache' \
  --exclude '.steam' \
  ~/ /run/media/bob/$MEDIA/$HOST/bob/
  
# backup email data
if [ -d /home/bob/.cache/evolution ] ; then
   rsync -aAXv --delete /home/bob/.cache/evolution /run/media/bob/$MEDIA/$HOST/bob/.cache/  
fi

# backup qemu images (if any)
if ! [ -e /var/lib/libvirt/images ] ; then
   echo -e "\nNo qemu images to backup"
   exit 1
fi

rsync -av --progress --delete /var/lib/libvirt/images/ /run/media/bob/$MEDIA/$HOST/images/
