#!/usr/bin/env bash
# Purpose: Keep Arch updated and pinky clean
# Author : Daniel Wayne Armstrong <hello@dwarmstrong.org>

set -euo pipefail

load_libraries () {
# https://gitlab.com/dwarmstrong/homebin/-/blob/master/lib_homebin.sh
libhome="${HOME}/.local/bin/lib_homebin.sh"
if [[ -f "${libhome}" ]]; then
  # shellcheck source=/dev/null
  source "${libhome}"
else
  echo "[$(date +'%Y-%m-%dT%H:%M:%S')]: ${libhome} not found."
  exit 1
fi
}

main() {
PACLOG="${HOME}/pacnew.log"

load_libraries

# https://gitlab.com/dwarmstrong/homebin/-/blob/master/arch_pkglist
echo_blue "==> generate list of installed packages"
arch_pkglist

# Generate new mirror selection. Verbosely select the 5 most recently synchronized
# HTTPS mirrors located in either Canada or Germany, sort them by download speed,
# and overwrite mirrorlist:
echo_blue "==> generate mirrorlist"
sudo reflector --verbose -f 20 --protocol https --latest 15 --sort rate \
--country US --save /etc/pacman.d/mirrorlist

echo_blue "==> --sync, --refresh, --upgrades"
sudo pacman -Syu

# Search files from packages:
echo_blue "==> sync pkgfile database"
sudo pkgfile -u

# Clean package cache:
echo_blue "==> clean package cache"
# * Remove all cached versions of uninstalled packages
sudo paccache -ruk0
# * Delete all cached versions of installed packages, except for most recent 3
sudo paccache -rv

echo_blue "==> orphans and dropped packages"
sudo pacman -Qtd || true

# Logs
echo_blue "==> failed systemd services"
systemctl --failed

echo_blue "==> errors in logfiles"
sudo journalctl -p 3 -b

# https://wiki.archlinux.org/title/Pacman/Pacnew_and_Pacsave
sudo updatedb
locate --existing --regex "\.pac(new|save)$" > "$PACLOG"
if [ -s "$PACLOG" ]; then
    echo_blue "==> .pacnew and/or .pacsave files available"
    cat "$PACLOG"
fi
}

# (O< -- Let's go!
# (/)_
main "$@"
