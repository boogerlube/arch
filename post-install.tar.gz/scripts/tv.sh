device="/run/media/bob/Backup1"

if ! [ -e $device ] ; then
  echo -e "\nBackup device not mounted."
  exit
fi

# Backup TVArchive from drwho via sshfs
rsync -av --progress --delete root@drwho:/mnt/user/Backup/Media/TVArchive/ $device/TVArchive/
# Backup TV from pinky via NFS mount
rsync -av --progress --delete  /media/pinky/TV/ $device/TV/

