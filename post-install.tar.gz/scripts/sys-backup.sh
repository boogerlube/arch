HOST=$(hostname)
MEDIA=$(lsblk | awk '/run/ {print $7}')

cecho(){
  RED="\033[1;91m"
  GREEN="\033[1;92m"  
  YELLOW="\033[1;93m" 
  CYAN="\033[1;96m"
	BLUE="\\033[1;94m"
  NC="\033[0m" # No Color

  printf "${!1}${2} ${NC}\n"
}

cecho "CYAN" "\nReady to backup media to device: "$MEDIA".\n"


while true ; do

read -p "Is this correct? (y/n) " yn

case $yn in 
    [yY] ) cecho "GREEN" "\nProceeding....";
       break;;
    [nN] ) cecho "RED" "\nAborting!\n\n";
       exit;;
    * ) cecho "YELLOW" "\ninvalid response\n\n";;
esac

done

cecho "GREEN" "\nBackup begin\n\n"

sudo rsync -aAXv --delete --exclude=/dev/* --exclude=/proc/* --exclude=/sys/* --exclude /home/bob/.cache --exclude=/tmp/* --exclude=/run/* --exclude=/mnt/* --exclude=/media/* --exclude="swapfile" --exclude="lost+found" --exclude=".VirtualBoxVMs" --exclude=".ecryptfs" / $MEDIA/$HOST
sudo rsync -aAXv --delete /home/bob/.cache/evolution $MEDIA/$HOST/home/bob/.cache/
#
#Restore with:
#
#sudo rsync -aAXv --delete --exclude="lost+found" $MEDIA/$HOST /
