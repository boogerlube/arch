git config --global user.name "boogerlube"
git config --global user.email "bob@languy.com"