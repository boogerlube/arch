
####################################################################
###             Make an Arch ISO with custom installer           ###
####################################################################

#make sure we have the tools installed
sudo pacman -S --noconfirm --needed archiso

# clone installer files into CD image
#git clone https://github.com/boogerlube/arch ~/tmp/arch
#mv ~/tmp/arch/* ~/archlive/airootfs/root/
#rm -rf ~/tmp/arch
rm -rf ~/archlive/airootfs/root/*
cp ~/projects/arch-install/arch/* ~/archlive/airootfs/root/
echo -e "\n"

while true; do
  read -p "Have you updated the installer files? (Y/N)" yn
  case $yn in
    [Yy]* ) sudo mkarchiso -v -w /tmp/archiso-temp -o /home/bob/Desktop /home/bob/archlive; break;;
    [Nn]* ) exit;;
    * ) echo "Please answer yes or no";;
  esac
done

sudo rm -rf /tmp/archiso-temp    
