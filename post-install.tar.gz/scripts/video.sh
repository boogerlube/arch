#!/bin/sh
xrandr --output HDMI-1 --rate 143.91 --primary --mode 2560x1440 --pos 0x1440 --rotate normal --output HDMI-2 --primary --rate 143.91 --mode 2560x1440 --pos 0x0 --rotate normal --output HDMI-3 --off --output HDMI-4 --off --output DP-1 --off --output DP-2 --off --output DP-3 --off --output DP-4 --off
