rsync -av --progress --delete ~/Books/ root@drwho:/mnt/user/Backup/Calibre/ 
