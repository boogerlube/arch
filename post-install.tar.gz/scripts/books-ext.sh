rsync -av --progress --delete ~/Books/ /run/media/bob/Music/Books/
 
