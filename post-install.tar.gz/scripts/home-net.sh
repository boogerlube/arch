# export list of all installed packages
pacman -Qqen > ~/pkglist.txt
pacman -Qqem > ~/pkglist-aur.txt


HOST=$(hostname)
MEDIA="/media/Pika"

if ! [ -e /media/Pika ] ; then
   sudo mkdir -p /media/Pika
fi

# mount backup storage
sudo mount -t nfs brain:/mnt/user/backup $MEDIA

cecho(){
  RED="\033[1;91m"
  GREEN="\033[1;92m"  
  YELLOW="\033[1;93m" 
  CYAN="\033[1;96m"
	BLUE="\\033[1;94m"
  NC="\033[0m" # No Color

  printf "${!1}${2} ${NC}\n"
}

cecho "CYAN" "\nReady to backup media to device: "$MEDIA".\n"


while true ; do

read -p "Is this correct? (y/n) " yn

case $yn in 
    [yY] ) cecho "GREEN" "\nProceeding....";
       break;;
    [nN] ) cecho "RED" "\nAborting!\n\n";
       sudo umount /media/Pika
       exit;;
    * ) cecho "YELLOW" "\ninvalid response\n\n";;
esac

done

cecho "GREEN" "\nBackup begin\n\n"

# Make sure disk device exists before beginning
if ! [ -e $MEDIA ] ; then
   echo -e "\nBackup device ("$MEDIA") is not available!"
   sudo umount /media/Pika
   exit 1
fi

# Create directory if it doesn't exit
if ! [ -e $MEDIA/machines/$HOST ] ; then
   mkdir -p $MEDIA/machines/$HOST
fi

rsync -aAXv --progress --delete \
  --exclude 'yay' \
  --exclude 'Music' \
  --exclude 'Books' \
  --exclude '.cache' \
  --exclude '.cargo' \
  --exclude '.config/google-chrome' \
  --exclude '.local/share/Trash/' \
  --exclude '.local/state/syncthing' \
  --exclude '.mozilla' \
  --exclude '.npm' \
  --exclude '.ssh' \
  --exclude '.steam' \
  --exclude '.var' \
  --exclude '.yarn' \
 ~/ $MEDIA/machines/$HOST/bob/
  
# backup email data
if [ -d /home/bob/.cache/evolution ] ; then
   rsync -aAXv --delete /home/bob/.cache/evolution/ $MEDIA/machines/$HOST/evolution/  
fi

# backup qemu images (if any)
if ! [ -e /var/lib/libvirt/images ] ; then
   echo -e "\nNo qemu images to backup"
   sudo umount /media/Pika
   exit 1
fi

rsync -av --progress --delete /var/lib/libvirt/images/ $MEDIA/machines/$HOST/images/
sudo umount /media/Pika
