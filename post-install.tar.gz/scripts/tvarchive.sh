rsync -av --progress --delete root@drwho:/mnt/user/Backup/Media/TVArchive/  /run/media/bob/TVArchive/
