sleep 5
wmctrl -r TorrentBox -t 1
