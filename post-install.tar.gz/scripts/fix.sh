clear
echo -e "                                                        Synchronizing music\n"
rclone sync /media/pinky/Music dropbox:/Music --dropbox-batch-mode sync --dropbox-batch-size 1000 --dropbox-batch-timeout 10s --checkers 4 --transfers 4 --tpslimit 9 --progress
