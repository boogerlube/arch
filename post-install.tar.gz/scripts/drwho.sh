device="/run/media/bob/DrWho"

if ! [ -e $device ] ; then
  echo -e "\nBackup device not mounted.\n\n"
  exit
fi

rsync -av --progress --delete root@drwho:/mnt/user/Backup/ $device/Backup/
rsync -av --progress --delete /media/share/ $device/Share/
rsync -av --progress --delete /media/torrent/ $device/Torrents/ 
