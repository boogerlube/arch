rclone sync ~/Books dropbox:/Books --dropbox-batch-mode sync --dropbox-batch-size 1000 --dropbox-batch-timeout 10s --checkers 4 --transfers 4 --tpslimit 12 --progress 
