#!/bin/sh
xrandr --output HDMI-1 --rate 120.01 --primary --mode 2560x1440 --pos 0x1440 --rotate normal --output HDMI-2 --primary --rate 120.01 --mode 2560x1440 --pos 0x0 --rotate normal --output HDMI-3 --off --output HDMI-4 --off --output DP-1 --off --output DP-2 --off --output DP-3 --off --output DP-4 --off
