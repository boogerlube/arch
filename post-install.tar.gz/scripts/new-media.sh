if ! [ -e /run/media/bob/Red-2TB ] ; then
  echo -e "\nBackup device not mounted."
  exit
fi

rsync -av --progress --delete  root@pinky:/mnt/user/media/Music/ /run/media/bob/Red-2TB/Music/
rsync -av --progress --delete  root@pinky:/mnt/user/media/Mvid/ /run/media/bob/Red-2TB/Mvid/
rsync -av --progress --delete ~/Books/ /run/media/bob/Red-2TB/Books/
rsync -av --progress --delete ~/Books/ root@pinky:/mnt/user/media/books/ 
clear
echo -e "                                                        Synchronizing books\n"
rclone sync ~/Books dropbox:/Books --dropbox-batch-mode sync --dropbox-batch-size 1000 --dropbox-batch-timeout 10s --checkers 4 --transfers 4 --tpslimit 12 --progress
clear
echo -e "                                                        Synchronizing music\n"
rclone sync /media/pinky/Music dropbox:/Music --dropbox-batch-mode sync --dropbox-batch-size 1000 --dropbox-batch-timeout 10s --checkers 4 --transfers 4 --tpslimit 12 --progress
