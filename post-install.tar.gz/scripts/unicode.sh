#!/bin/sh

#export BASHOPTS=xpg_echo

from=0000 to=0800
from=$(printf '%d' "0x$from") to=$(printf '%d' "0x$to")
while test "$from" -le "$to"; do
    #num=$(printf '%04x' "$from")
    #bash -c "echo -n \"\u$num\""
    echo $from
    printf '\u'"$from"'\n'
    from=$((from+1))
done
