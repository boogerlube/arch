rsync -av --progress --delete ~/Books/ root@pinky:/mnt/user/media/books/ 
