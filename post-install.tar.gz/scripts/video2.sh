xrandr --output HDMI-A-0 --mode 2560x1440 --rate 143.91 --primary --output HDMI-A-1 --mode 2560x1440 --rate 143.91 --left-of HDMI-A-0 --output HDMI-A-2 --mode 2560x1440
