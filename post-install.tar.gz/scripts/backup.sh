duplicity ~ b2://0011d8e4bb9ad750000000001:K001JJuNKIFtP2g+1aCoZfKskjV3I1Q@spearmint

# duplicity ~ b2://[keyID]:[application key]@[B2 bucket name]

# duplicity restore --file-to-restore [folder name from backup] b2://[keyID]:[application key]@[B2 bucket name] [restore path]
