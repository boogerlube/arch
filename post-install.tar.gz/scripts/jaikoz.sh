cd ~/jaikoz/bin
./jaikoz