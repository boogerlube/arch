cecho(){
  RED="\033[1;91m"
  GREEN="\033[1;92m"  
  YELLOW="\033[1;93m" 
  CYAN="\033[1;96m"
	BLUE="\\033[1;94m"
  NC="\033[0m" # No Color

  printf "${!1}${2} ${NC}\n"
}

echo -ne "\n\n"

#Verify update Dropbox
while true ; do

read -p "Should we update Dropbox? " yn

case $yn in 
    [yY] ) cecho "GREEN" "Updating Dropbox confirmed....";
       dropbox=true;  
       break;;
    [nN] ) cecho "RED" "No Dropbox for you!";
       dropbox=false;
       break;;
    * ) cecho "YELLOW" "invalid response";;
esac

done

#Find external device
device=$(lsblk | awk '/run/ {print $7}')
cecho "CYAN" "\nReady to backup media to device: "$device".\n"

#Verify backup device
while true ; do

read -p "Is this correct? (y/n) " yn

case $yn in 
    [yY] ) cecho "GREEN" "\nProceeding....";
       break;;
    [nN] ) cecho "RED" "\nAborting!\n\n";
       exit;;
    * ) cecho "YELLOW" "\ninvalid response\n\n";;
esac

done

cecho "GREEN" "\nBackup begin\n\n"

rsync -av --progress --delete  root@brain:/mnt/user/media/Music/ $device/Music/
rsync -av --progress --delete  root@brain:/mnt/user/media/Mvid/ $device/Mvid/
rsync -av --progress --delete ~/Books/ $device/Books/
rsync -av --progress --delete ~/Books/ root@brain:/mnt/user/media/books/
 
if $dropbox ; then 
   clear
   cecho "GREEN" "                                                        Synchronizing books\n"
   rclone sync ~/Books dropbox:/Books --dropbox-batch-mode sync --dropbox-batch-size 1000 --dropbox-batch-timeout 10s --checkers 4 --transfers 4 --tpslimit 12 --progress
   clear
   cecho "GREEN" "                                                        Synchronizing music\n"
   rclone sync /media/pinky/Music dropbox:/Music --dropbox-batch-mode sync --dropbox-batch-size 1000 --dropbox-batch-timeout 10s --checkers 4 --transfers 4 --tpslimit 12 --progress
fi
