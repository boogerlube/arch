sudo journalctl -p 3 -b

