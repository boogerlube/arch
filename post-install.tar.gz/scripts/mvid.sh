rsync -av --progress --delete  root@pinky:/mnt/user/media/Mvid/ /run/media/bob/Music/Mvid/
