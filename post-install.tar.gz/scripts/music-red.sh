rsync -av --progress --delete  root@pinky:/mnt/user/media/Music/ /run/media/bob/Red-2TB/Music/
rsync -av --progress --delete root@pinky:/mnt/user/media/books/ /run/media/bob/Red-2TB/Books/
rsync -av --progress --delete root@pinky:/mnt/user/media/Mvid/ /run/media/bob/Red-2TB/Mvid/
