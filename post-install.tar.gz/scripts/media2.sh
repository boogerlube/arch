cecho(){
  RED="\033[1;91m"
  GREEN="\033[1;92m"  
  YELLOW="\033[1;93m" 
  CYAN="\033[1;96m"
	BLUE="\\033[1;94m"
  NC="\033[0m" # No Color

  printf "${!1}${2} ${NC}\n"
}

device=$(lsblk | awk '/run/ {print $7}')
cecho "CYAN" "\nReady to backup media to device: "$device".\n"


while true ; do

read -p "Is this correct? (y/n) " yn

case $yn in 
    [yY] ) cecho "GREEN" "\nProceeding....";
       break;;
    [nN] ) cecho "RED" "\nAborting!\n\n";
       exit;;
    * ) cecho "YELLOW" "\ninvalid response\n\n";;
esac

done

cecho "GREEN" "\nBackup begin\n\n"

rsync -av --progress --delete  root@pinky:/mnt/user/media/Music/ $device/Music/
rsync -av --progress --delete  root@pinky:/mnt/user/media/Mvid/ $device/Mvid/
rsync -av --progress --delete ~/Books/ $device/Books/
rsync -av --progress --delete ~/Books/ root@pinky:/mnt/user/media/books/ 
#clear
#cecho "GREEN" "                                                        Synchronizing books\n"
#rclone sync ~/Books dropbox:/Books --dropbox-batch-mode sync --dropbox-batch-size 1000 --dropbox-batch-timeout 10s --checkers 4 --transfers 4 --tpslimit 12 --progress
#clear
#cecho "GREEN" "                                                        Synchronizing music\n"
#rclone sync /media/pinky/Music dropbox:/Music --dropbox-batch-mode sync --dropbox-batch-size 1000 --dropbox-batch-timeout 10s --checkers 4 --transfers 4 --tpslimit 12 --progress
